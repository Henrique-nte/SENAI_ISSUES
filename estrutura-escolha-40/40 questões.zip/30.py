#Verificar múltiplos de 7 e 3
#Solicite um número e verifique se ele é múltiplo de 7 e 3. Exiba "Sim" ou "Não".